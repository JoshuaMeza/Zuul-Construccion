Built in Java 17.0.1
Run in terminal:
	java -jar --enable-preview Zuul.jar